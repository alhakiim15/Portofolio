<form method = "">
    Kode Kategori Wisata : <input type="text"></br>
    Nama Kategori Wisata : <input type= "text"></br>
    Keterangan Kategori Wisata : <input type = "text"></br>
    Referensi Kategori Wisata : <input type = "text"><br>

    <input type = "submit" value="Simpan" name="Simpan"/>
    <input type = "Reset" value="Batal">
</form>