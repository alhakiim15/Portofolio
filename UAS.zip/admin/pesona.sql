-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Des 2023 pada 23.44
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pesona`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `alhakim`
--

CREATE TABLE `alhakim` (
  `hotel0164` char(4) NOT NULL,
  `hotelNAMA` char(160) NOT NULL,
  `hotelALAMAT` varchar(250) NOT NULL,
  `kategori0164` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `alhakim`
--

INSERT INTO `alhakim` (`hotel0164`, `hotelNAMA`, `hotelALAMAT`, `kategori0164`) VALUES
('164', 'kecelakaan', 'kompas', 'jakarta');

-- --------------------------------------------------------

--
-- Struktur dari tabel `berita`
--

CREATE TABLE `berita` (
  `beritaKODE` char(120) NOT NULL,
  `beritaNAMA` char(160) NOT NULL,
  `penerbit` char(250) NOT NULL,
  `beritaALAMAT` char(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `destinasi`
--

CREATE TABLE `destinasi` (
  `destinasiKODE` char(4) NOT NULL,
  `destinasiNAMA` varchar(120) NOT NULL,
  `kategoriKODE` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `destinasi`
--

INSERT INTO `destinasi` (`destinasiKODE`, `destinasiNAMA`, `kategoriKODE`) VALUES
('', '', 'Kate'),
('jep', 'tuhan', 'ast'),
('li', 'jgo', 'K001'),
('tata', 'tyty', 'apak'),
('wi', 'rt', 'Kate'),
('wo', 'rw', 'Kate');

-- --------------------------------------------------------

--
-- Struktur dari tabel `fotodestinasi`
--

CREATE TABLE `fotodestinasi` (
  `fotodestinasiKODE` char(4) NOT NULL,
  `fotodestinasiNAMA` char(120) NOT NULL,
  `fotodestinasiFile` char(120) NOT NULL,
  `destinasiKODE` char(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `fotodestinasi`
--

INSERT INTO `fotodestinasi` (`fotodestinasiKODE`, `fotodestinasiNAMA`, `fotodestinasiFile`, `destinasiKODE`) VALUES
('12', 'su', 'bg-05.jpg', ''),
('dagi', 'makanan', 'daging.jpg', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenisbarang`
--

CREATE TABLE `jenisbarang` (
  `barangTYPE` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jenisbarang`
--

INSERT INTO `jenisbarang` (`barangTYPE`) VALUES
('Barang'),
('Makanan'),
('Minuman');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenishp`
--

CREATE TABLE `jenishp` (
  `hpTYPE` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `jenishp`
--

INSERT INTO `jenishp` (`hpTYPE`) VALUES
('APPLE'),
('OPPO'),
('ROG'),
('SAMSUNG'),
('XIAOMI');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategoriwisata`
--

CREATE TABLE `kategoriwisata` (
  `kategoriKODE` char(4) NOT NULL,
  `kategoriNAMA` char(25) NOT NULL,
  `kategoriKET` text NOT NULL,
  `kategoriREFERENCE` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `kategoriwisata`
--

INSERT INTO `kategoriwisata` (`kategoriKODE`, `kategoriNAMA`, `kategoriKET`, `kategoriREFERENCE`) VALUES
('K001', 'Budaya', 'sebuah adab yg baik adalah bagus', 'Buku Agama');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penjualanhp`
--

CREATE TABLE `penjualanhp` (
  `hpKODE` char(4) NOT NULL,
  `hpNAMA` char(160) NOT NULL,
  `garansiKODE` varchar(250) NOT NULL,
  `hpTYPE` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penjualanhp`
--

INSERT INTO `penjualanhp` (`hpKODE`, `hpNAMA`, `garansiKODE`, `hpTYPE`) VALUES
('10', 'Iphone14', '1 Tahun', 'APPLE'),
('11', 'ROG', '1 Tahun', 'OPPO');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pusatoleh`
--

CREATE TABLE `pusatoleh` (
  `barangKODE` char(4) NOT NULL,
  `barangNAMA` char(160) NOT NULL,
  `barangHARGA` char(250) NOT NULL,
  `barangTYPE` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pusatoleh`
--

INSERT INTO `pusatoleh` (`barangKODE`, `barangNAMA`, `barangHARGA`, `barangTYPE`) VALUES
('1', 'coca-cola', '7000', 'Minuman'),
('2', 'gulali', '3000', 'Makanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `resto`
--

CREATE TABLE `resto` (
  `restoMAKAN` char(120) NOT NULL,
  `restoMINUM` char(120) NOT NULL,
  `restoMENU` char(120) NOT NULL,
  `fotoMENU` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `resto`
--

INSERT INTO `resto` (`restoMAKAN`, `restoMINUM`, `restoMENU`, `fotoMENU`) VALUES
('11', 'daging1', 'user.png', 'Makanan'),
('12', 'daging', 'th.jpg', 'Makanan'),
('13', 'teh', 'segar.jpg', 'Minuman');

-- --------------------------------------------------------

--
-- Struktur dari tabel `restomenu`
--

CREATE TABLE `restomenu` (
  `fotoMENU` char(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `restomenu`
--

INSERT INTO `restomenu` (`fotoMENU`) VALUES
('Makanan'),
('Minuman');

-- --------------------------------------------------------

--
-- Struktur dari tabel `travel`
--

CREATE TABLE `travel` (
  `namaTRAVEL` char(120) NOT NULL,
  `tujuanTRAVEL` char(120) NOT NULL,
  `tanggalTRAVEL` date NOT NULL,
  `jenisTRAVEL` char(250) NOT NULL,
  `fotoTRAVEL` char(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `travel`
--

INSERT INTO `travel` (`namaTRAVEL`, `tujuanTRAVEL`, `tanggalTRAVEL`, `jenisTRAVEL`, `fotoTRAVEL`) VALUES
('ali', 'jawa', '3000-12-11', 'qt', 'bg-05.jpg'),
('jepier', 'jakarta', '2022-11-09', 'Garuda', 'segar.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `useradmin`
--

CREATE TABLE `useradmin` (
  `userKODE` char(4) NOT NULL,
  `userNAMA` char(30) NOT NULL,
  `userEMAIL` char(60) NOT NULL,
  `userPASS` char(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `useradmin`
--

INSERT INTO `useradmin` (`userKODE`, `userNAMA`, `userEMAIL`, `userPASS`) VALUES
('164', 'alhakiim', 'simulasi@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `alhakim`
--
ALTER TABLE `alhakim`
  ADD PRIMARY KEY (`hotel0164`);

--
-- Indeks untuk tabel `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`beritaKODE`);

--
-- Indeks untuk tabel `destinasi`
--
ALTER TABLE `destinasi`
  ADD PRIMARY KEY (`destinasiKODE`);

--
-- Indeks untuk tabel `fotodestinasi`
--
ALTER TABLE `fotodestinasi`
  ADD PRIMARY KEY (`fotodestinasiKODE`);

--
-- Indeks untuk tabel `jenisbarang`
--
ALTER TABLE `jenisbarang`
  ADD PRIMARY KEY (`barangTYPE`);

--
-- Indeks untuk tabel `jenishp`
--
ALTER TABLE `jenishp`
  ADD PRIMARY KEY (`hpTYPE`);

--
-- Indeks untuk tabel `kategoriwisata`
--
ALTER TABLE `kategoriwisata`
  ADD PRIMARY KEY (`kategoriKODE`);

--
-- Indeks untuk tabel `penjualanhp`
--
ALTER TABLE `penjualanhp`
  ADD PRIMARY KEY (`hpKODE`);

--
-- Indeks untuk tabel `pusatoleh`
--
ALTER TABLE `pusatoleh`
  ADD PRIMARY KEY (`barangKODE`);

--
-- Indeks untuk tabel `resto`
--
ALTER TABLE `resto`
  ADD PRIMARY KEY (`restoMAKAN`);

--
-- Indeks untuk tabel `restomenu`
--
ALTER TABLE `restomenu`
  ADD PRIMARY KEY (`fotoMENU`);

--
-- Indeks untuk tabel `travel`
--
ALTER TABLE `travel`
  ADD PRIMARY KEY (`namaTRAVEL`);

--
-- Indeks untuk tabel `useradmin`
--
ALTER TABLE `useradmin`
  ADD PRIMARY KEY (`userKODE`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
